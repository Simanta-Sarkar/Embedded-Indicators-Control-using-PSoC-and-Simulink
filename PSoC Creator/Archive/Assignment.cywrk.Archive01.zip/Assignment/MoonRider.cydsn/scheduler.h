/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <project.h>

void Scheduler_Init(void);
void Scheduler_Run(void);

#endif
/* [] END OF FILE */
