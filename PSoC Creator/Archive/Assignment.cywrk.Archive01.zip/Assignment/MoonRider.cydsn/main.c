/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "scheduler.h"
#include "gpio_driver.h"
#include "uart_driver.h"

int main(void)
{
    CyGlobalIntEnable; // Enable global interrupts (not used in simulation)

    Scheduler_Init();

    // Simulation loop for 10 seconds (100 ticks)
    for (uint32_t tick = 0; tick < 100; tick++) {
        // Simulate button presses
        if (tick == 10) { // At 1 second
            Sim_SetButtonState(BUTTON_LEFT, BUTTON_PRESSED);
            UART_Log("Simulated Left Button Pressed");
        } else if (tick == 20) { // At 2 seconds
            Sim_SetButtonState(BUTTON_LEFT, !BUTTON_PRESSED);
            UART_Log("Simulated Left Button Released");
        } else if (tick == 30) { // At 3 seconds
            Sim_SetButtonState(BUTTON_RIGHT, BUTTON_PRESSED);
            UART_Log("Simulated Right Button Pressed");
        } else if (tick == 40) { // At 4 seconds
            Sim_SetButtonState(BUTTON_RIGHT, !BUTTON_PRESSED);
            UART_Log("Simulated Right Button Released");
        } else if (tick == 50) { // At 5 seconds
            Sim_SetButtonState(BUTTON_LEFT, BUTTON_PRESSED);
            Sim_SetButtonState(BUTTON_RIGHT, BUTTON_PRESSED);
            UART_Log("Simulated Both Buttons Pressed (Hazard)");
        } else if (tick == 60) { // At 6 seconds
            Sim_SetButtonState(BUTTON_LEFT, !BUTTON_PRESSED);
            Sim_SetButtonState(BUTTON_RIGHT, !BUTTON_PRESSED);
            UART_Log("Simulated Both Buttons Released (Hazard Off)");
        }

        Scheduler_Run();
        CyDelay(100); // Simulate 100 msec delay per tick
    }

    UART_Close();
    return 0;
}
/* [] END OF FILE */