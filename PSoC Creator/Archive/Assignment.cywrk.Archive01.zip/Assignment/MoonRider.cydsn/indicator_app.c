/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "indicator_app.h"
#include "pwm_driver.h"
#include "uart_driver.h"
#include <stdbool.h>

// Indicator states
static bool left_indicator_active = false;
static bool right_indicator_active = false;
static bool hazard_active = false;
static uint32_t last_toggle_time = 0;

void IndicatorApp_Init(void) {
    left_indicator_active = false;
    right_indicator_active = false;
    hazard_active = false;
    last_toggle_time = 0;
}

void IndicatorApp_Run(ButtonState *left_button, ButtonState *right_button, uint32_t current_time) {
    // Detect button presses (1 sec = 10 ticks)
    bool left_pressed = (left_button->state == BUTTON_PRESSED && left_button->prev_state != BUTTON_PRESSED);
    bool right_pressed = (right_button->state == BUTTON_PRESSED && right_button->prev_state != BUTTON_PRESSED);
    static uint32_t left_press_start = 0;
    static uint32_t right_press_start = 0;
    static bool left_held = false;
    static bool right_held = false;
    
    if (left_pressed) {
        left_press_start = current_time;
        left_held = false;
    }
    if (right_pressed) {
        right_press_start = current_time;
        right_held = false;
    }
    
    if (left_button->state == BUTTON_PRESSED && (current_time - left_press_start) >= 10) {
        left_held = true;
    }
    if (right_button->state == BUTTON_PRESSED && (current_time - right_press_start) >= 10) {
        right_held = true;
    }
    
    // Indicator logic
    if (left_held && right_held) {
        if (hazard_active) {
            hazard_active = false;
            left_indicator_active = false;
            right_indicator_active = false;
            PWM_SetState(PWM_LEFT, 0);
            PWM_SetState(PWM_RIGHT, 0);
            UART_Log("Hazard OFF");
        } else {
            hazard_active = true;
            left_indicator_active = false;
            right_indicator_active = false;
            UART_Log("Hazard ON");
        }
        left_held = false;
        right_held = false;
    } else if (left_held) {
        if (hazard_active) {
            hazard_active = false;
            left_indicator_active = true;
            right_indicator_active = false;
            PWM_SetState(PWM_RIGHT, 0);
            UART_Log("Hazard OFF");
            UART_Log("Left Indicator ON");
        } else if (left_indicator_active) {
            left_indicator_active = false;
            PWM_SetState(PWM_LEFT, 0);
            UART_Log("Left Indicator OFF");
        } else {
            left_indicator_active = true;
            right_indicator_active = false;
            PWM_SetState(PWM_RIGHT, 0);
            UART_Log("Left Indicator ON");
        }
        left_held = false;
    } else if (right_held) {
        if (hazard_active) {
            hazard_active = false;
            left_indicator_active = false;
            right_indicator_active = true;
            PWM_SetState(PWM_LEFT, 0);
            UART_Log("Hazard OFF");
            UART_Log("Right Indicator ON");
        } else if (right_indicator_active) {
            right_indicator_active = false;
            PWM_SetState(PWM_RIGHT, 0);
            UART_Log("Right Indicator OFF");
        } else {
            right_indicator_active = true;
            left_indicator_active = false;
            PWM_SetState(PWM_LEFT, 0);
            UART_Log("Right Indicator ON");
        }
        right_held = false;
    }
    
    // Toggle LEDs every 300 msec (3 ticks)
    if ((current_time - last_toggle_time) >= 3) {
        last_toggle_time = current_time;
        if (hazard_active) {
            PWM_Toggle(PWM_LEFT);
            PWM_Toggle(PWM_RIGHT);
        } else if (left_indicator_active) {
            PWM_Toggle(PWM_LEFT);
        } else if (right_indicator_active) {
            PWM_Toggle(PWM_RIGHT);
        }
    }
}
/* [] END OF FILE */
