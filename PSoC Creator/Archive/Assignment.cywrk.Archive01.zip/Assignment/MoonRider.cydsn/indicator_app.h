/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef INDICATOR_APP_H
#define INDICATOR_APP_H

#include "gpio_driver.h"

void IndicatorApp_Init(void);
void IndicatorApp_Run(ButtonState *left_button, ButtonState *right_button, uint32_t current_time);

#endif
/* [] END OF FILE */
